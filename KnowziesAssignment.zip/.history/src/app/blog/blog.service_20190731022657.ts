import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class BlogService {
  constructor(private _http: HttpClient) {}

  getCountryList() {
    return this._http.get("/farmers/country/all");
  }

  addCountry(country) {
    return this._http.post("/farmers/country/add", country);
  }