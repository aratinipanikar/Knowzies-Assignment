import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { BloglistComponent } from "./bloglist/bloglist.component";
import { CreateblogComponent } from "./createblog/createblog.component";

const routes: Routes = [
  { path: "bloglist", component: BloglistComponent },
  { path: "createblog", component: CreateblogComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BlogRoutingModule {}
