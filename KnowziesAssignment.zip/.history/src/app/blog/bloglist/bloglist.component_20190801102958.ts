import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-bloglist",
  templateUrl: "./bloglist.component.html",
  styleUrls: ["./bloglist.component.css"]
})
export class BloglistComponent implements OnInit {
  columns = [
    { name: "Name" },
    { name: "Category" },
    { name: "Date" },
    { name: "Description" },
    { name: "Tags" }
  ];
  rows = [
    {
      name: "Singham",
      category: "comedy,Action",
      date: "20aug2018",
      description: "Directedd by Rohit ",
      tags: "movies, comedy,action"
    },
    {
      moviename: "Singham",
      category: "comedy,Action",
      date: "20aug2018",
      description: "Directedd by Rohit ",
      tags: "movies, comedy,action"
    }
  ];

  constructor() {}

  ngOnInit() {}
}
