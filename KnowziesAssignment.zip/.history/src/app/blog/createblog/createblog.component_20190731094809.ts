import { Component, OnInit } from "@angular/core";
import { BlogService } from "../blog.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
/*
TODO:
1. Naming
2. Validations
3. Template driven
4. Datepicker 
5. Checkbox - with value array in ngFor loop*/
export class CreateblogComponent implements OnInit {
  _router: any;

  model: any = {};

  constructor(public blogsrvice: BlogService, private router: Router) {}

  ngOnInit() {}

  onSubmit() {
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(this.model));
  }
}
