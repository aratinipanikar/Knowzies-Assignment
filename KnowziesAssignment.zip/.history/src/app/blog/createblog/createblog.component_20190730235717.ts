import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
export class CreateblogComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
  selectmulti() {
    document.getElementById("mySelect").multiple = true;
  }
}
