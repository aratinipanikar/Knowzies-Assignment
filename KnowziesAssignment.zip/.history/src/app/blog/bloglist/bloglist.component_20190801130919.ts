import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: "app-bloglist",
  templateUrl: "./bloglist.component.html",
  styleUrls: ["./bloglist.component.css"]
})
export class BloglistComponent implements OnInit {
  columns = [
    { name: "Name" },
    { name: "Category" },
    { name: "Date" },
    { name: "Description" },
    { name: "Tags" }
  ];
  rows = [
    {
      name: "Singham",
      category: "comedy,Action",
      date: "20 Aug 2018",
      description: "Directed by Rohit",
      tags: "movies,bollywood"
    },
    {
      name: "Mai Hu Na",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Farah",
      tags: "Movies,bollywood"
    },
    {
      name: "Bazigar",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Abbas",
      tags: "Movies,bollywood"
    },
    {
      name: "Mai Hu Na",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Farah",
      tags: "Movies,bollywood"
    },
    {
      name: "Pink",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Aniruddha",
      tags: "Movies,bollywood"
    },
    {
      name: "Sairat",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Nagraj",
      tags: "Movies,Marathi"
    },
    {
      name: "Padmavati",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Sanjay",
      tags: "Movies,bollywood"
    },
    {
      name: "Cocktail",
      category: "comedy,Drama",
      date: "20aug2018",
      description: "Directed by Homi",
      tags: "Movies,bollywood"
    },
    {
      name: "Dabbang",
      category: "Action,Drama",
      date: "20aug2018",
      description: "Directed by Abhinav",
      tags: "Movies,bollywood"
    },
    {
      name: "Sholey",
      category: "Action,Drama",
      date: "20aug1990",
      description: "Directed by Salim",
      tags: "Movies,bollywood"
    }
  ];
  p: number[] = [];
  config: any;
  collection = [];
  constructor(private route: ActivatedRoute, private router: Router) {
    this.config = {
      currentPage: 1,
      itemsPerPage: 2
    };
     this.route.queryParamMap
            .map(params => params.get('page'))
            .subscribe(page => this.config.currentPage = page);

    for (let i = 1; i <= 100; i++) {
      this.collection.push(`item ${i}`);
    }

  }


     pageChange(newPage: number) {
		this.router.navigate([''], { queryParams: { page: newPage } });
	}
  }

  ngOnInit() {}
}
