import { Component, OnInit } from "@angular/core";
import { BlogService } from "../blog.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
export class CreateblogComponent implements OnInit {
  _router: any;
  public blogs = { movies: [{}] };
  constructor(public blogsrvice: BlogService, private router: Router) {
    this.blogs = {
      movies: [
        {
          title: "Singham",
          category: "Comedy,Action",
          Publishedon: "2 Jan 2019",
          description: "Best comedy and action movie directed by Rohit Shetty.",
          tags: "movie,bollywood,action,comedy"
        },
        {
          title: "Chennai Express",
          category: "Comedy,Action",
          Publishedon: "20 Nov 2018",
          description: "Best comedy and action movie directed by Rohit Shetty.",
          tags: "movie,bollywood,action,comedy"
        }
      ]
    };
  }

  ngOnInit() {}

  onSubmit() {
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(this.model));
  }

  addBlog() {
    // this.blogsrvice.CreateBlog(this.blogs).subscribe(Response => {
    alert(JSON.stringify(this.blogs));
    console.log(this.blogs, "this is data");
    this._router.navigate(["/bloglist"]);
    // });
  }
}
