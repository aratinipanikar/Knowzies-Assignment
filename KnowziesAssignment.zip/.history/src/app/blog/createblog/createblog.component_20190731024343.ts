import { Component, OnInit } from "@angular/core";
import { BlogService } from "../blog.service";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
export class CreateblogComponent implements OnInit {
  _router: any;
  constructor(public blogsrvice: BlogService) {}
  blogs: object = {};
  ngOnInit() {}

  addBlog(blogs) {
    this.blogsrvice.CreateBlog(this.blogs).subscribe(Response => {
     ) alert(this.blogs);
        this._router.navigate(["./bloglist"]);
      
     });
  }
}
