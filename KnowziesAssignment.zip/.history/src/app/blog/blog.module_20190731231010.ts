import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BloglistComponent } from "./bloglist/bloglist.component";
import { CreateblogComponent } from "./createblog/createblog.component";
import { BlogRoutingModule } from "./blog-routingmodule";

import { FormsModule } from "@angular/forms";
import { BlogService } from "./blog.service";
import { AppRoutingModule } from "../app-routing.module";

@NgModule({
  declarations: [BloglistComponent, CreateblogComponent],
  imports: [CommonModule, BlogRoutingModule, FormsModule, AppRoutingModule],
  providers: [BlogService]
})
export class BlogModule {}
