import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class BlogService {
  constructor(private _http: HttpClient) {}
  blogs: object = {};
  GetBlogList() {
    let httpHeaders = new HttpHeaders();
    httpHeaders = httpHeaders.append("Content-Type", "application/json");
    httpHeaders = httpHeaders.append("Accept", "application/json");

    return this._http.get("#" {
      headers: httpHeaders
    });
  }

  CreateBlog(blogs) {
    let httpHeaders = new HttpHeaders();
    httpHeaders = httpHeaders.append("Content-Type", "application/json");
    httpHeaders = httpHeaders.append("Accept", "application/json");

    return this._http.post("#" , blogs,{
      headers: httpHeaders
    })
  };
  }