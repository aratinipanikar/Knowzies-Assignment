import { Component, OnInit } from "@angular/core";
import { BlogService } from "../blog.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
/*
TODO:
1. Naming
2. Validations
3. Template driven
4. Datepicker 
5. Checkbox - with value array in ngFor loop
*/
export class CreateblogComponent implements OnInit {
  _router: any;

  model: any = {};
  orders: any = {};

  constructor(public blogsrvice: BlogService, private router: Router) {}

  ngOnInit() {
    this.orders = [
      { id: 100, name: "order 1" },
      { id: 200, name: "order 2" },
      { id: 300, name: "order 3" },
      { id: 400, name: "order 4" }
    ];
  }

  onSubmit() {
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(this.model));
  }
}
