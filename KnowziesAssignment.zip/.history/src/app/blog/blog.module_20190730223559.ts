import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BloglistComponent } from './bloglist/bloglist.component';
import { CreateblogComponent } from './createblog/createblog.component';

@NgModule({
  declarations: [BloglistComponent, CreateblogComponent],
  imports: [
    CommonModule
  ]
})
export class BlogModule { }
