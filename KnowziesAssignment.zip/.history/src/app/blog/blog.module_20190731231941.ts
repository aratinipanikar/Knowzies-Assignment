import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BloglistComponent } from "./bloglist/bloglist.component";
import { CreateblogComponent } from "./createblog/createblog.component";
import { BlogRoutingModule } from "./blog-routingmodule";
import { Ng2TableModule } from "ng2-table/ng2-table";
import { FormsModule } from "@angular/forms";
import { BlogService } from "./blog.service";
import { AppRoutingModule } from "../app-routing.module";

@NgModule({
  declarations: [BloglistComponent, CreateblogComponent],
  imports: [
    CommonModule,
    BlogRoutingModule,
    FormsModule,
    AppRoutingModule,
    Ng2TableModule
  ],
  providers: [BlogService]
})
export class BlogModule {}
