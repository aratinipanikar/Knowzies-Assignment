import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-bloglist",
  templateUrl: "./bloglist.component.html",
  styleUrls: ["./bloglist.component.css"]
})
export class BloglistComponent implements OnInit {
  columns = [
    { prop: "Movie Name" },
    { name: "Category" },
    { name: "Date" },
    { name: "description" }
  ];
  rows = [
    {
      moviename: "Singham",
      category: "comedy,Action",
      date: "20aug2018",
      description: "Directedd by Rohit Shetty"
    },
    {
      moviename: "Singham",
      category: "comedy,Action",
      date: "20aug2018",
      description: "Directedd by Rohit Shetty"
    }
  ];

  constructor() {}

  ngOnInit() {}
}
