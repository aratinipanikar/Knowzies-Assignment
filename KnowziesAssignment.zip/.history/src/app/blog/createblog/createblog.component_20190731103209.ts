import { Component, OnInit } from "@angular/core";
import { BlogService } from "../blog.service";
import { Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  FormArray,
  FormControl,
  ValidatorFn
} from "@angular/forms";

@Component({
  selector: "app-createblog",
  templateUrl: "./createblog.component.html",
  styleUrls: ["./createblog.component.css"]
})
/*
TODO:
1. Naming
2. Validations
3. Template driven
4. Datepicker 
5. Checkbox - with value array in ngFor loop
*/
export class CreateblogComponent implements OnInit {
  _router: any;

  model: any = {};

  orders = [
    { id: 100, name: "order 1" },
    { id: 200, name: "order 2" },
    { id: 300, name: "order 3" },
    { id: 400, name: "order 4" }
  ];

  constructor(
    public blogsrvice: BlogService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    const controls = this.orders.map(c => new FormControl(false));
    controls[0].setValue(true);

    this.form = this.formBuilder.group({
      orders: new FormArray(controls, minSelectedCheckboxes(1))
    });
  }

  ngOnInit() {}

  onSubmit() {
    alert("SUCCESS!! :-)\n\n" + JSON.stringify(this.model));
  }
}
