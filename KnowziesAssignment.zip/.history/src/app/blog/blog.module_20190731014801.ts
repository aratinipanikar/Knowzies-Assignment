import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BloglistComponent } from "./bloglist/bloglist.component";
import { CreateblogComponent } from "./createblog/createblog.component";
import { BlogRoutingModule } from "./blog-routingmodule";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
@NgModule({
  declarations: [BloglistComponent, CreateblogComponent],
  imports: [CommonModule, BlogRoutingModule, NgxDatatableModule]
})
export class BlogModule {}
