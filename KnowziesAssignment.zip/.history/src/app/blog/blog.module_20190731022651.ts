import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { BloglistComponent } from "./bloglist/bloglist.component";
import { CreateblogComponent } from "./createblog/createblog.component";
import { BlogRoutingModule } from "./blog-routingmodule";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { FormsModule } from "@angular/forms";
import { BlogService } from "./blog.service";

@NgModule({
  declarations: [BloglistComponent, CreateblogComponent],
  imports: [CommonModule, BlogRoutingModule, FormsModule, NgxDatatableModule],
  providers: [BlogService]
})
export class BlogModule {}
